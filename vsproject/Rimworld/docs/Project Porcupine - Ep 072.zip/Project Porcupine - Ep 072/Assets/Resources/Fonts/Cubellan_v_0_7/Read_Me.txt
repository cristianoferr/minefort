

	Thanks for downloading!



	"Cubellan", "Cubellan Bold", "Cubellan Italic" 
	and "Cubellan Small Caps" 
	Are currently in early beta stage. 
	Bold Italic is in the making.

	What comes to shape and spacing, there are few obvious 
	differences between Regular and other styles
	and I will fix those in future versions.
	
	There ate plans formore characters and larger language support, 
	same as Bold, Italic And Bold Italic for Small Caps.
	
	Final version will be published in Open Type - Format. 
	
	

	Feedback and suggestions are much appreciated, 
	same as links to your creations if you used this font.
	


	Have Fun!
	
		 - Jyrki Ihalainen -
		 - yardan74(at)gmail.com -

 