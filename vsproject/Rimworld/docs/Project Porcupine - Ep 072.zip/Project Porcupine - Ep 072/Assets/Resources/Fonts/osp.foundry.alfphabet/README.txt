
FONTLOG.txt: the font design-oriented changelog
http://scripts.sil.org/OFL-FAQ_web#00e3bd04

Alfphabet-IV.ttf: ttf font sources
http://www.truetype-typography.com/ttspec.htm

OFL-1.1.txt: copyright notice header + license
OFL-1.1-header.txt: license header for separate files
OFL-FAQ.txt: Frequently Asked Questions about the license and its collaboration model
http://scripts.sil.org/OFL


